package io.wamly.assessment.controller;

import io.wamly.assessment.model.Answer;
import io.wamly.assessment.model.Interview;
import io.wamly.assessment.repository.InterviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/interviews")
public class InterviewController {

    @Autowired
    private InterviewRepository interviewRepository;

    /**
     * Retrieves all interviews.
     *
     * @return A list of all interviews
     */
    @GetMapping
    public List<Interview> getAllInterviews() {
        return interviewRepository.findAll();
    }

    /**
     * Retrieves a specific interview by ID.
     *
     * @param id The ID of the interview to retrieve
     * @return The interview if found, or a 404 response if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Interview> getInterviewById(@PathVariable("id") String id) {
        Optional<Interview> interview = interviewRepository.findById(id);
        if (interview.isPresent()) {
            return ResponseEntity.ok(interview.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Creates a new interview.
     *
     * @param interview The interview to create
     * @return The created interview
     */
    @PostMapping
    public ResponseEntity<Interview> createInterview(@RequestBody Interview interview) {
        for (Answer answer : interview.getAnswers()) {
            answer.setInterview(interview);
        }
        Interview savedInterview = interviewRepository.save(interview);
        return ResponseEntity.ok(savedInterview);
    }

    /**
     * Updates an existing interview.
     *
     * @param id               The ID of the interview to update
     * @param updatedInterview The updated interview data
     * @return The updated interview if found, or a 404 response if not found
     */
    @PutMapping("/{id}")
    public ResponseEntity<Interview> updateInterview(@PathVariable("id") String id, @RequestBody Interview updatedInterview) {
        Optional<Interview> interview = interviewRepository.findById(id);
        if (interview.isPresent()) {
            Interview existingInterview = interview.get();
            existingInterview.update(updatedInterview);

            Interview savedInterview = interviewRepository.save(existingInterview);
            return ResponseEntity.ok(savedInterview);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Deletes a specific interview by ID.
     *
     * @param id The ID of the interview to delete
     * @return A no-content response if the interview was deleted, or a 404 response if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInterview(@PathVariable("id") String id) {
        Optional<Interview> interview = interviewRepository.findById(id);
        if (interview.isPresent()) {
            interviewRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
