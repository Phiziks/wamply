package io.wamly.assessment.controller;

import io.wamly.assessment.model.Answer;
import io.wamly.assessment.repository.AnswerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Controller class for handling CRUD operations on answers.
 */
@RestController
@RequestMapping("/answers")
public class AnswerController {

    @Autowired
    private AnswerRepository answerRepository;

    /**
     * Retrieves all answers.
     *
     * @return A list of all answers
     */
    @GetMapping
    public List<Answer> getAllAnswers() {
        return answerRepository.findAll();
    }

    /**
     * Retrieves a specific answer by ID.
     *
     * @param id The ID of the answer to retrieve
     * @return The answer if found, or a 404 response if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Answer> getAnswerById(@PathVariable("id") String id) {
        Optional<Answer> answer = answerRepository.findById(id);
        if (answer.isPresent()) {
            return ResponseEntity.ok(answer.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Creates a new answer.
     *
     * @param answer The answer to create
     * @return The created answer
     */
    @PostMapping
    public Answer createAnswer(@RequestBody Answer answer) {
        return answerRepository.save(answer);
    }

    /**
     * Updates an existing answer.
     *
     * @param id            The ID of the answer to update
     * @param updatedAnswer The updated answer data
     * @return The updated answer if found, or a 404 response if not found
     */
    @PutMapping("/{id}")
    public ResponseEntity<Answer> updateAnswer(@PathVariable("id") String id, @RequestBody Answer updatedAnswer) {
        Optional<Answer> answer = answerRepository.findById(id);
        if (answer.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Answer existingAnswer = answer.get();
        existingAnswer.update(updatedAnswer);

        Answer savedAnswer = answerRepository.save(existingAnswer);
        return ResponseEntity.ok(savedAnswer);
    }

    /**
     * Deletes a specific answer by ID.
     *
     * @param id The ID of the answer to delete
     * @return A success response if the answer was deleted, or a 404 response if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAnswer(@PathVariable("id") String id) {
        if (answerRepository.existsById(id)) {
            answerRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
