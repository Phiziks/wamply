package io.wamly.assessment.services;

import io.wamly.assessment.dto.AnswerCommentRequest;
import io.wamly.assessment.dto.InterviewCommentRequest;
import io.wamly.assessment.dto.UpdateCommentRequest;
import io.wamly.assessment.interfaces.ICommentsService;
import io.wamly.assessment.model.Answer;
import io.wamly.assessment.model.Comment;
import io.wamly.assessment.model.Interview;
import io.wamly.assessment.model.User;
import io.wamly.assessment.repository.AnswerRepository;
import io.wamly.assessment.repository.CommentRepository;
import io.wamly.assessment.repository.InterviewRepository;
import io.wamly.assessment.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class CommentServiceImpl implements ICommentsService {


    private final CommentRepository commentRepository;

    private final InterviewRepository interviewRepository;

    private final UserRepository userRepository;

    private final AnswerRepository answerRepository;

    public CommentServiceImpl(CommentRepository commentRepository,
                              InterviewRepository interviewRepository,
                              UserRepository userRepository,
                              AnswerRepository answerRepository) {
        this.commentRepository = commentRepository;
        this.interviewRepository = interviewRepository;
        this.userRepository = userRepository;
        this.answerRepository = answerRepository;

    }


    @Override
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @Override
    public boolean deleteComment(String commentId) {
        if (commentRepository.existsById(commentId)) {
            commentRepository.deleteById(commentId);
            return true;
        }

        return false;
    }

    @Override
    public void addCommentToInterview(InterviewCommentRequest interviewCommentRequest) {
        Optional<User> user = userRepository.findById(interviewCommentRequest.getUserId());

        if (user.isPresent()) {
            Optional<Interview> interview = interviewRepository.findById(interviewCommentRequest.getInterviewId());

            if (interview.isPresent()) {

                Comment comment = new Comment();
                comment.setContent(interviewCommentRequest.getComment());
                comment.setUser(user.get());

                interview.get().getComments().add(comment);

                interviewRepository.save(interview.get());
            } else {
                throw new NoSuchElementException("interview does not exist in the system");
            }
        } else {
            throw new NoSuchElementException("user does not exist in the system");
        }


    }

    @Override
    public void addCommentToAnswer(AnswerCommentRequest answerCommentRequest) {
        Optional<User> user = userRepository.findById(answerCommentRequest.getUserId());

        if (user.isPresent()) {
            Optional<Answer> interview = answerRepository.findById(answerCommentRequest.getAnswerId());

            if (interview.isPresent()) {

                Comment comment = new Comment();
                comment.setContent(answerCommentRequest.getComment());
                comment.setUser(user.get());

                interview.get().getComments().add(comment);

                answerRepository.save(interview.get());
            } else {
                throw new NoSuchElementException("answer does not exist in the system");
            }
        } else {
            throw new NoSuchElementException("user does not exist in the system");
        }

    }

    @Override
    public List<Comment> getAllCommentsByUser(String userId) {
        return commentRepository.findAllByUser(userId);
    }

    @Override
    public List<Comment> getAllCommentsByInterview(String interviewId) {
        Optional<Interview> interview = interviewRepository.findById(interviewId);
        if (interview.isPresent()) {
            return interview.get().getComments();
        } else {
            throw new NoSuchElementException("interview does not exist in the system");
        }

    }

    @Override
    public List<Comment> getAllCommentsByAnswer(String answerId) {
        Optional<Answer> answer = answerRepository.findById(answerId);
        if (answer.isPresent()) {
            return answer.get().getComments();
        } else {
            throw new NoSuchElementException("answer does not exist in the system");
        }

    }

    @Override
    public Comment updateComment(UpdateCommentRequest updateCommentRequest) {
        Optional<Comment> comment = commentRepository.findById(updateCommentRequest.getCommentId());
        if (comment.isPresent()) {
            comment.get().setContent(updateCommentRequest.getComment());
            return commentRepository.save(comment.get());
        } else {
            throw new NoSuchElementException("comment does not exist in the system");
        }
    }


}
