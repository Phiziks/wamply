package io.wamly.assessment.controller;

import io.wamly.assessment.model.User;
import io.wamly.assessment.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    /**
     * Retrieves all users.
     *
     * @return A list of all users
     */
    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Retrieves a specific user by ID.
     *
     * @param id The ID of the user to retrieve
     * @return The user if found, or a 404 response if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") String id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Creates a new user.
     *
     * @param user The user to create
     * @return The created user
     */
    @PostMapping
    public User createUser(@RequestBody User user) {
//        user.setId(UUID.randomUUID().toString()); // Generate a new ID for the user
        return userRepository.save(user);
    }

    /**
     * Updates an existing user.
     *
     * @param id          The ID of the user to update
     * @param updatedUser The updated user data
     * @return The updated user if found, or a 404 response if not found
     */
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id") String id, @RequestBody User updatedUser) {
        Optional<User> user = userRepository.findById(id);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        User existingUser = user.get();
        existingUser.update(updatedUser);
        User savedUser = userRepository.save(existingUser);
        return ResponseEntity.ok(savedUser);
    }

    /**
     * Deletes a specific user by ID.
     *
     * @param id The ID of the user to delete
     * @return A no-content response if the user was deleted, or a 404 response if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable("id") String id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            userRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
