package io.wamly.assessment.interfaces;

import io.wamly.assessment.dto.AnswerCommentRequest;
import io.wamly.assessment.dto.InterviewCommentRequest;
import io.wamly.assessment.dto.UpdateCommentRequest;
import io.wamly.assessment.model.Comment;

import java.util.List;

public interface ICommentsService {

    List<Comment> getAllComments();

    boolean deleteComment(String commentId);

    void addCommentToInterview(InterviewCommentRequest interviewCommentRequest);

    void addCommentToAnswer(AnswerCommentRequest answerCommentRequest);

    List<Comment> getAllCommentsByUser(String userId);

    List<Comment> getAllCommentsByInterview(String interviewId);

    List<Comment> getAllCommentsByAnswer(String answerId);

    Comment updateComment(UpdateCommentRequest updateCommentRequest);
}
