package io.wamly.assessment.controller;

import io.wamly.assessment.dto.AnswerCommentRequest;
import io.wamly.assessment.dto.InterviewCommentRequest;
import io.wamly.assessment.dto.UpdateCommentRequest;
import io.wamly.assessment.interfaces.ICommentsService;
import io.wamly.assessment.model.Comment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {
    private final ICommentsService commentsService;

    public CommentController(ICommentsService commentsService) {
        this.commentsService = commentsService;
    }

    @GetMapping
    public List<Comment> getAllComments() {
        return commentsService.getAllComments();
    }

    @PostMapping("/interview")
    public ResponseEntity<String> addInterviewComment(@RequestBody InterviewCommentRequest interviewCommentRequest) {
        //the assumption I have is that there would be a button to add/save a comment and this would be done one comment at a time

        commentsService.addCommentToInterview(interviewCommentRequest);

        return ResponseEntity.ok("comment has been added to interview");
    }

    @PostMapping("/answer")
    public ResponseEntity<String> addAnswerComment(@RequestBody AnswerCommentRequest answerCommentRequest) {
        commentsService.addCommentToAnswer(answerCommentRequest);

        return ResponseEntity.ok("comment has been added to the Answer");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable("id") String id) {
        if (commentsService.deleteComment(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<List<Comment>> getUserComments(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentsService.getAllCommentsByUser(id));

    }

    @GetMapping("answer/{id}")
    public ResponseEntity<List<Comment>> getAnswerComments(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentsService.getAllCommentsByAnswer(id));

    }

    @GetMapping("interview/{id}")
    public ResponseEntity<List<Comment>> getInterviewComments(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentsService.getAllCommentsByInterview(id));

    }

    @PutMapping("/update")
    public ResponseEntity<Comment> updateComment(@RequestBody UpdateCommentRequest updateCommentRequest) {
        return ResponseEntity.ok(commentsService.updateComment(updateCommentRequest));

    }
}
