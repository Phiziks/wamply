package io.wamly.assessment.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;

import java.util.*;

/**
 * This entity represents an interview that was completed by a candidate.
 * An interview consists of a set of answers.
 */

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "interview")
public class Interview {
    @Id
    @Column(name = "id", nullable = false)
    @Builder.Default
    private String id = UUID.randomUUID().toString();

    @Builder.Default
    @OneToMany(mappedBy = "interview", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Answer> answers = new HashSet<>();  //!< Answers given by candidates in an interview.

    @JoinTable(
            name = "interview_comment",
            joinColumns = @JoinColumn(name = "interview_id"),
            inverseJoinColumns = @JoinColumn(name = "comment_id")
    )
    @OneToMany(cascade = CascadeType.ALL)
    private List<Comment> comments = new ArrayList<>();

    /**
     * Updates the interview with new answer information.
     * Retains the common answers and adds the new answers to the interview.
     *
     * @param interview The interview object containing updated answer information
     */
    public void update(Interview interview) {
        answers.retainAll(interview.getAnswers());
        for (Answer answer : answers) {
            answer.update(interview.getAnswers().stream().filter(a -> a.getId().equals(answer.getId())).findFirst().get());
        }

        answers.addAll(interview.getAnswers());
        for (Answer answer : answers) {
            answer.setInterview(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Interview interview = (Interview) o;
        return Objects.equals(id, interview.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}