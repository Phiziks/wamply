package io.wamly.assessment.dto;

import lombok.Data;

@Data
public class UpdateCommentRequest {
    String commentId;
    String comment;
}
