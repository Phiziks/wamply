package io.wamly.assessment.dto;

import lombok.Data;

@Data
public class InterviewCommentRequest {

    String userId;
    String interviewId;
    String comment;

}
