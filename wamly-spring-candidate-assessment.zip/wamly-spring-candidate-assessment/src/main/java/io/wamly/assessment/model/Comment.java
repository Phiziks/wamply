package io.wamly.assessment.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "comment")
public class Comment {

    @Id
    @Column(name = "id", nullable = false)
    @Builder.Default
    private String id = UUID.randomUUID().toString();

    @Column(name = "created_date", nullable = false)
    LocalDateTime createdDate = LocalDateTime.now();

    @Column(name = "content", nullable = false)
    private String content;

    @OneToOne
    User user;


}
