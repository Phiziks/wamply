package io.wamly.assessment.dto;

import lombok.Data;

@Data
public class AnswerCommentRequest {

    String userId;
    String answerId;
    String comment;

}
