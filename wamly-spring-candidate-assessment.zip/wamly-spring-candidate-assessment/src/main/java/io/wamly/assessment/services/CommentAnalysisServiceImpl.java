package io.wamly.assessment.services;

import io.wamly.assessment.interfaces.ICommentAnalysisService;
import io.wamly.assessment.interfaces.ICommentsService;
import io.wamly.assessment.model.Comment;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class CommentAnalysisServiceImpl implements ICommentAnalysisService {

    private final ICommentsService commentsService;
    private List<String> wordsToIgnore;

    public CommentAnalysisServiceImpl(ICommentsService commentsService){
        //wordsToIgnore = loadWordsToIgnore();
        wordsToIgnore = new ArrayList<>(); //TODO: remove and uncomment above when fixed.
        this.commentsService = commentsService;
    }


    @Override
    public int countWordsInAllComments() {
        return countNumWords(commentsService.getAllComments());
    }

    @Override
    public int countWordsInInCommentsByUser(String userId) {
        return countNumWords(commentsService.getAllCommentsByUser(userId));
    }

    @Override
    public int countWordsInInCommentsByInterview(String interviewId) {
        return countNumWords(commentsService.getAllCommentsByInterview(interviewId));
    }

    @Override
    public int countWordsInInCommentsByAnswer(String answerId) {
        return countNumWords(commentsService.getAllCommentsByAnswer(answerId));
    }


    private int countNumWords(List<Comment> comments) {
        int wordCount = 0;
        for (Comment comment : comments) {
            String[] words = comment.getContent().split("\\s+");
            for (String word : words) {
                if (!word.matches("\\p{Punct}+") || !existsInIgnoredWords(word)) {
                    wordCount++;
                }
            }
        }
        return wordCount;
    }

    private boolean existsInIgnoredWords(String word) {

        for (String s : wordsToIgnore) {
            if (s.equalsIgnoreCase(word)) {
                return true;
            }
        }

        return false;

    }

    private List<String> loadWordsToIgnore() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        List<String> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(Objects.requireNonNull(classLoader.getResource("filler_words.csv")).getFile()))) {
            String line;
            while ((line = br.readLine()) != null) {
                records.add(line);
            }
        }
        return records;
    }
}


