package io.wamly.assessment.controller;

import io.wamly.assessment.interfaces.ICommentAnalysisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/comments/analysis")
public class CommentsAnalysisController {

    public final ICommentAnalysisService commentAnalysisService;

    public CommentsAnalysisController(ICommentAnalysisService commentAnalysisService) {
        this.commentAnalysisService = commentAnalysisService;

    }

    @GetMapping("interview/{id}")
    public ResponseEntity<Integer> getInterviewAnalysis(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentAnalysisService.countWordsInInCommentsByInterview(id));

    }

    @GetMapping("")
    public ResponseEntity<Integer> getAllAnalysis() {
        return ResponseEntity.ok(commentAnalysisService.countWordsInAllComments());

    }

    @GetMapping("answer/{id}")
    public ResponseEntity<Integer> getAnswerAnalysis(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentAnalysisService.countWordsInInCommentsByAnswer(id));

    }

    @GetMapping("user/{id}")
    public ResponseEntity<Integer> getUserAnalysis(@PathVariable("id") String id) {
        return ResponseEntity.ok(commentAnalysisService.countWordsInInCommentsByUser(id));

    }

}
