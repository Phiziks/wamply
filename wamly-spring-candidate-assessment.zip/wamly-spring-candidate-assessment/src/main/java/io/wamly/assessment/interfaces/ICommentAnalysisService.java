package io.wamly.assessment.interfaces;

public interface ICommentAnalysisService {
    int countWordsInAllComments();

    int countWordsInInCommentsByUser(String userId);

    int countWordsInInCommentsByInterview(String interviewId);

    int countWordsInInCommentsByAnswer(String answerId);
}
