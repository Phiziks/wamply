package io.wamly.assessment.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 *  A Wamly user that can view interviews submitted by candidates.
 *
 *  @apiNote A candidate is not a user.
 */

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "users")
public class User {
    @Id
    @Column(name = "id", nullable = false)
    @Builder.Default
    private String id = UUID.randomUUID().toString();

    @Column(name = "email", nullable = false)
    private String email;   //!< The email address of the user.

    @Column(name = "name", nullable = false)
    private String name;    //!< The full-name of the user.



    /**
     * Updates the user with new user information.
     *
     * @param user The user object containing updated information
     */
    public void update(User user) {
        this.email = user.getEmail();
        this.name = user.getName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}